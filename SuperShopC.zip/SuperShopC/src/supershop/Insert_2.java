/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package supershop;

/**
 *
 * @author SWO SIRAJ
 */

import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

class JComboCheckBox extends JComboBox
{   
   public JComboCheckBox() {
      init();
   }
    
   public JComboCheckBox(JCheckBox[] items) {
      super(items);
      init();
   }
    
   public JComboCheckBox(Vector items) {
      super(items);
      init();
   }
    
   public JComboCheckBox(ComboBoxModel aModel) {
      super(aModel);
      init();
   }
    
   private void init() {
      setRenderer(new ComboBoxRenderer());
      addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent ae) {
            itemSelected();
         }
      });
   }
  
   private void itemSelected() {
      if (getSelectedItem() instanceof JCheckBox) {
         JCheckBox jcb = (JCheckBox)getSelectedItem();
         jcb.setSelected(!jcb.isSelected());
      }
   }
  
   class ComboBoxRenderer implements ListCellRenderer {
      private JLabel label;
       
      public ComboBoxRenderer() {
         setOpaque(true);
      }
       
      public Component getListCellRendererComponent(JList list, Object value, int index,
                                                    boolean isSelected, boolean cellHasFocus) {
         if (value instanceof Component) {
            Component c = (Component)value;
            if (isSelected) {
               c.setBackground(list.getSelectionBackground());
               c.setForeground(list.getSelectionForeground());
            } else {
               c.setBackground(list.getBackground());
               c.setForeground(list.getForeground());
            }
              
            return c;
         } else {
            if (label ==null) {
               label = new JLabel(value.toString());
            }
            else {
               label.setText(value.toString());
            }
                
            return label;
         }
      }
   }
}
  



public class Insert_2 extends javax.swing.JFrame {
    Connection c;
    Statement s;
    ResultSet r;
    JComboCheckBox j; JComboCheckBox j1 ;
    
    public void type(){Vector v = new Vector();
      v.add(new JCheckBox("Meat", false));
      v.add(new JCheckBox("Fish", false));
      v.add(new JCheckBox("Fruits and Vegetables", false));
      v.add(new JCheckBox("Cosmetics", false));
      v.add(new JCheckBox("Dry Items", false));
      v.add(new JCheckBox("Snacks", false));
      v.add(new JCheckBox("Spices", false));
      v.add(new JCheckBox("Chocolates", false));
      j = new JComboCheckBox(v);
      j.setSize(jPanel1.getWidth(), jPanel1.getHeight());
      jPanel1.add(j);}
    
    
    public void ID(){
        
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            c= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:aurna","project","Oracle_1");
            s= c.createStatement();
            r=s.executeQuery("select product_id from product");
             Vector v = new Vector();
            while(r.next()){
                String s1= r.getInt(1)+"";
                v.add(new JCheckBox(s1, false));
            }
          
            j1 = new JComboCheckBox(v);
            j1.setSize(jPanel3.getWidth(), jPanel3.getHeight());
            jPanel3.add(j1); add(jPanel3);
            
        } catch (SQLException ex) {
            Logger.getLogger(Discount.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Discount.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    
    
    private void UPDATEtable(){
     Discount d= new Discount();
        DefaultTableModel model=(DefaultTableModel) (d.jTable1).getModel();
try{



  s= c.createStatement();
    String query="select offer_name, offer_id, starting_date, ending_date, offer_discount, case when sysdate between starting_date and ending_date then 'valid' else 'invalid' end as status from discount";

    ResultSet r1 = s.executeQuery(query);
    while(r1.next()){
        String id = r1.getString("offer_id");
     String name = r1.getString("offer_name");
       String start = r1.getString("starting_date");
       String end = r1.getString("ending_date");
       String discount = r1.getString("offer_discount");
       String status=r1.getString("status");
      model.addRow(new Object[] { id,name,start, end,discount,status});

    }
}

catch(Exception e)
{
    System.out.print(e);

}
    }
    
    /**
     * Creates new form Insert_2
     */
    public Insert_2() {
        try {
            initComponents();
            this.getContentPane().setBackground(new Color(255,255,153));
            Class.forName("oracle.jdbc.OracleDriver");
            c= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:aurna","project","Oracle_1");
            // jPanel1.getContentPane().setBackground(new Color(255,255,153));
            
            type();
            ID();
            j.setEnabled(false); j1.setEnabled(false);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Insert_2.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Insert_2.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        offer_id = new javax.swing.JTextField();
        offerName = new javax.swing.JTextField();
        startingDate = new javax.swing.JTextField();
        endingDate = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        amount = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jCheckBox1 = new javax.swing.JCheckBox();
        jCheckBox2 = new javax.swing.JCheckBox();
        jPanel3 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 102));
        setForeground(new java.awt.Color(0, 153, 153));
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(255, 255, 153));
        jPanel1.setForeground(new java.awt.Color(0, 153, 153));
        jPanel1.setOpaque(false);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 40, Short.MAX_VALUE)
        );

        offer_id.setFont(new java.awt.Font("Calibri Light", 0, 20)); // NOI18N
        offer_id.setForeground(new java.awt.Color(0, 134, 134));
        offer_id.setOpaque(false);
        offer_id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                offer_idActionPerformed(evt);
            }
        });

        offerName.setFont(new java.awt.Font("Calibri Light", 0, 20)); // NOI18N
        offerName.setForeground(new java.awt.Color(0, 134, 134));
        offerName.setOpaque(false);
        offerName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                offerNameActionPerformed(evt);
            }
        });

        startingDate.setFont(new java.awt.Font("Calibri Light", 0, 20)); // NOI18N
        startingDate.setForeground(new java.awt.Color(0, 134, 134));
        startingDate.setOpaque(false);

        endingDate.setFont(new java.awt.Font("Calibri Light", 0, 20)); // NOI18N
        endingDate.setForeground(new java.awt.Color(0, 134, 134));
        endingDate.setOpaque(false);
        endingDate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                endingDateActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Calibri Light", 0, 20)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 134, 134));
        jLabel2.setText("Offer ID");

        jLabel3.setFont(new java.awt.Font("Calibri Light", 0, 20)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 134, 134));
        jLabel3.setText("Offer Name");

        jLabel4.setFont(new java.awt.Font("Calibri Light", 0, 20)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 134, 134));
        jLabel4.setText("Starting date");

        jLabel5.setFont(new java.awt.Font("Calibri Light", 0, 20)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 134, 134));
        jLabel5.setText("Ending Date");

        jButton2.setFont(new java.awt.Font("Calibri Light", 0, 20)); // NOI18N
        jButton2.setForeground(new java.awt.Color(0, 134, 134));
        jButton2.setText("Okay");
        jButton2.setContentAreaFilled(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        amount.setFont(new java.awt.Font("Calibri Light", 0, 20)); // NOI18N
        amount.setForeground(new java.awt.Color(0, 134, 134));
        amount.setOpaque(false);

        jLabel6.setFont(new java.awt.Font("Calibri Light", 0, 20)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 134, 134));
        jLabel6.setText("Discount amount");

        jButton8.setFont(new java.awt.Font("Calibri Light", 0, 20)); // NOI18N
        jButton8.setForeground(new java.awt.Color(0, 134, 134));
        jButton8.setText("Reset");
        jButton8.setContentAreaFilled(false);
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jButton9.setFont(new java.awt.Font("Calibri Light", 0, 20)); // NOI18N
        jButton9.setForeground(new java.awt.Color(0, 134, 134));
        jButton9.setText("Exit");
        jButton9.setContentAreaFilled(false);
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        buttonGroup1.add(jCheckBox1);
        jCheckBox1.setFont(new java.awt.Font("Calibri Light", 0, 20)); // NOI18N
        jCheckBox1.setForeground(new java.awt.Color(0, 153, 153));
        jCheckBox1.setText("Product Type");
        jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox1ActionPerformed(evt);
            }
        });

        buttonGroup1.add(jCheckBox2);
        jCheckBox2.setFont(new java.awt.Font("Calibri Light", 0, 20)); // NOI18N
        jCheckBox2.setForeground(new java.awt.Color(0, 153, 153));
        jCheckBox2.setText("Product ID");
        jCheckBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox2ActionPerformed(evt);
            }
        });

        jPanel3.setBackground(new java.awt.Color(255, 255, 102));
        jPanel3.setForeground(new java.awt.Color(0, 153, 153));
        jPanel3.setOpaque(false);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 42, Short.MAX_VALUE)
        );

        jLabel7.setFont(new java.awt.Font("Calibri Light", 0, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 134, 134));
        jLabel7.setText("Insert Discount Record");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(52, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jCheckBox1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel6)
                        .addComponent(jLabel5)
                        .addComponent(jLabel3)
                        .addComponent(jLabel2)
                        .addComponent(jLabel4))
                    .addComponent(jCheckBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(offer_id)
                            .addComponent(endingDate, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(startingDate, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(offerName, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(amount, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(89, 89, 89)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(59, 59, 59))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(65, 65, 65)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 62, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(offer_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(offerName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(startingDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(endingDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addGap(26, 26, 26)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(amount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jCheckBox1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jButton8)
                        .addGap(36, 36, 36)
                        .addComponent(jButton2)
                        .addGap(38, 38, 38)
                        .addComponent(jButton9)
                        .addGap(36, 36, 36)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jCheckBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(70, 70, 70))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void offerNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_offerNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_offerNameActionPerformed

    private void endingDateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_endingDateActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_endingDateActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        try {
            // TODO add your handling code here:
            
            s= c.createStatement();
            
            int id= Integer.parseInt(offer_id.getText());
            String name = offerName.getText();
            String start = startingDate.getText();
            String end= endingDate.getText();
            int amnt= Integer.parseInt(amount.getText());
            if(jCheckBox1.isSelected()){
            for(int i=0; i< j.getItemCount(); i++){
                if(j.getItemAt(i) instanceof JCheckBox){
                    if(((JCheckBox)j.getItemAt(i)).isSelected()){
                        String SID =((JCheckBox)j.getItemAt(i)).getText();
                        System.out.println(SID);
            r= s.executeQuery("select product_id from product where product_type='"+SID+"'");
            Vector vid=new Vector();
            while(r.next()){vid.add(r.getInt(1));}
            for(int j=0; j< vid.size(); j++)
            {
            int ID= (int)vid.get(j);
            ResultSet r2 =s.executeQuery("select product_id from discount where product_id = "+ID +" and ( starting_date between '"+start+"' and '"+end+"') or ( ending_date between '"+start+"' and '"+end+"')");
            if(!r2.next())
            {
            String sql="insert into discount(offer_name,offer_id,product_id,starting_date,ending_date,offer_discount) values('"+ name+"',"+id+","+ID+", to_Date('"+start+"'),to_Date('"+ end+"'),"+amnt+")";
            s.executeUpdate(sql);
            
            Discount d= new Discount();
            DefaultTableModel model=(DefaultTableModel) d.jTable1.getModel();

            while(model.getRowCount()>0){
                model.setRowCount(0);
            }
            UPDATEtable(); JOptionPane.showMessageDialog(null, " New Entry Saved");
            }}}} }
            }
            else if(jCheckBox2.isSelected())
            {for(int i=0; i< j1.getItemCount(); i++){
                if(j1.getItemAt(i) instanceof JCheckBox){
                    if(((JCheckBox)j1.getItemAt(i)).isSelected()){
                        String SID =((JCheckBox)j1.getItemAt(i)).getText();
                        System.out.println(SID);
                        int ID= Integer.parseInt(SID);    
            ResultSet r2 =s.executeQuery("select product_id from discount where product_id = "+ID +" and ( starting_date between '"+start+"' and '"+end+"') or ( ending_date between '"+start+"' and '"+end+"')");
            if(!r2.next())
            {
            String sql="insert into discount(offer_name,offer_id,product_id,starting_date,ending_date,offer_discount) values('"+ name+"',"+id+","+ID+", to_Date('"+start+"'),to_Date('"+ end+"'),"+amnt+")";
            s.executeUpdate(sql);
            Discount d= new Discount();
            //DefaultTableModel model=(DefaultTableModel) d.jTable1.getModel();

           // while(model.getRowCount()>0){
                //model.setRowCount(0);
           // }
            //UPDATEtable();
            JOptionPane.showMessageDialog(null, " New Entry Saved");
            } }}}}
            
            //JOptionPane.showMessageDialog(null, " New Entry Saved");

        } catch (SQLException ex) {
            Logger.getLogger(Discount.class.getName()).log(Level.SEVERE, null, ex);
        }
        //System.exit(0);
        
        Discount d= new Discount();
            DefaultTableModel model=(DefaultTableModel)(d.jTable1).getModel();

            while(model.getRowCount()>0){
                model.setRowCount(0);
                
            }
            UPDATEtable();
            
        setVisible(false); dispose();
       
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        offer_id.setText("");
        offerName.setText("");
        startingDate.setText("");
        endingDate.setText("");
        amount.setText("");
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // TODO add your handling code here:
        setVisible(false);
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox1ActionPerformed
        jCheckBox1.setSelected(!jCheckBox1.isSelected());
        if(jCheckBox1.isSelected()){j.setEnabled(true); }
        else if(!jCheckBox1.isSelected()){j.setEnabled(false); }
        if(jCheckBox2.isSelected()){j1.setEnabled(true); }
        else if(!jCheckBox2.isSelected()){j1.setEnabled(false); }
    }//GEN-LAST:event_jCheckBox1ActionPerformed

    private void offer_idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_offer_idActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_offer_idActionPerformed

    private void jCheckBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox2ActionPerformed
        jCheckBox2.setSelected(!jCheckBox2.isSelected());
        if(jCheckBox2.isSelected()){j1.setEnabled(true); }
        else if(!jCheckBox2.isSelected()){j1.setEnabled(false); }
        if(jCheckBox1.isSelected()){j.setEnabled(true); }
        else if(!jCheckBox1.isSelected()){j.setEnabled(false); }
    }//GEN-LAST:event_jCheckBox2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Insert_2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Insert_2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Insert_2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Insert_2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Insert_2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField amount;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JTextField endingDate;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JTextField offerName;
    private javax.swing.JTextField offer_id;
    private javax.swing.JTextField startingDate;
    // End of variables declaration//GEN-END:variables
}

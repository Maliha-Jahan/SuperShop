/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package supershop;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

/**
 *
 * @author Acer
 */
@Entity
@Table(name = "MEMBER", catalog = "", schema = "POLO")
@NamedQueries({
    @NamedQuery(name = "Member1.findAll", query = "SELECT m FROM Member1 m"),
    @NamedQuery(name = "Member1.findByMemberName", query = "SELECT m FROM Member1 m WHERE m.memberName = :memberName"),
    @NamedQuery(name = "Member1.findByMemberId", query = "SELECT m FROM Member1 m WHERE m.memberId = :memberId"),
    @NamedQuery(name = "Member1.findByJoiningDate", query = "SELECT m FROM Member1 m WHERE m.joiningDate = :joiningDate"),
    @NamedQuery(name = "Member1.findByExpiringDate", query = "SELECT m FROM Member1 m WHERE m.expiringDate = :expiringDate"),
    @NamedQuery(name = "Member1.findByMemberDiscount", query = "SELECT m FROM Member1 m WHERE m.memberDiscount = :memberDiscount")})
public class Member1 implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Column(name = "MEMBER_NAME")
    private String memberName;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Id
    @Basic(optional = false)
    @Column(name = "MEMBER_ID")
    private BigDecimal memberId;
    @Column(name = "JOINING_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date joiningDate;
    @Column(name = "EXPIRING_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date expiringDate;
    @Column(name = "MEMBER_DISCOUNT")
    private BigInteger memberDiscount;

    public Member1() {
    }

    public Member1(BigDecimal memberId) {
        this.memberId = memberId;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        String oldMemberName = this.memberName;
        this.memberName = memberName;
        changeSupport.firePropertyChange("memberName", oldMemberName, memberName);
    }

    public BigDecimal getMemberId() {
        return memberId;
    }

    public void setMemberId(BigDecimal memberId) {
        BigDecimal oldMemberId = this.memberId;
        this.memberId = memberId;
        changeSupport.firePropertyChange("memberId", oldMemberId, memberId);
    }

    public Date getJoiningDate() {
        return joiningDate;
    }

    public void setJoiningDate(Date joiningDate) {
        Date oldJoiningDate = this.joiningDate;
        this.joiningDate = joiningDate;
        changeSupport.firePropertyChange("joiningDate", oldJoiningDate, joiningDate);
    }

    public Date getExpiringDate() {
        return expiringDate;
    }

    public void setExpiringDate(Date expiringDate) {
        Date oldExpiringDate = this.expiringDate;
        this.expiringDate = expiringDate;
        changeSupport.firePropertyChange("expiringDate", oldExpiringDate, expiringDate);
    }

    public BigInteger getMemberDiscount() {
        return memberDiscount;
    }

    public void setMemberDiscount(BigInteger memberDiscount) {
        BigInteger oldMemberDiscount = this.memberDiscount;
        this.memberDiscount = memberDiscount;
        changeSupport.firePropertyChange("memberDiscount", oldMemberDiscount, memberDiscount);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (memberId != null ? memberId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Member1)) {
            return false;
        }
        Member1 other = (Member1) object;
        if ((this.memberId == null && other.memberId != null) || (this.memberId != null && !this.memberId.equals(other.memberId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "supershop.Member1[ memberId=" + memberId + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
